package com.ariba.training.web;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import com.ariba.training.domain.Product;

@FeignClient(name = "productservice", fallback = FallbackProductService.class)
public interface ProductService {
	
	@GetMapping("/products/{id}")
	public Product getById(@PathVariable("id")int id);

}

//@FeignClient(url = "http://google.co.in")
//interface GoogleApi{
//	@GetMapping("/search")
//	public String doSearch(@RequestParam("q")String query);
//}
